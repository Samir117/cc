<?php
    // Get typography props
    $ogo_typography_control = array();
    if( function_exists('ogo_typography_control') ){
        $ogo_typography_control = ogo_typography_control( 'menu', 'Montserrat', '500', 'latin', false, '17px', '25px' );
    }

	return array(
		'top_bar_section' => array(
            'title'     => esc_html_x('Top Bar', 'customizer', 'ogo'),
            'layout'    => array_merge(
                array(
                    'top_bar_wide' => array(
                        'default'   => false,
                        'type'      => 'checkbox',
                        'label'     => esc_html_x('Apply full-width top bar', 'customizer', 'ogo'),
                    ),
                    'top_bar_number' => array(
                        'type'      => 'text',
                        'label'     => esc_html_x('Phone Number', 'customizer', 'ogo'),
                        'default'   => "",
                    ),
                    'top_bar_email' => array(
                        'type'      => 'text',
                        'label'     => esc_html_x('Email', 'customizer', 'ogo'),
                        'default'   => "",
                        'separator' => 'line'
                    ),
                    'icon_custom_sb' => array(
                        'default'   => false,
                        'type'      => 'checkbox',
                        'label'     => esc_html_x('Add Custom Sidebar Icon', 'customizer', 'ogo')
                    ),
                     'top_bar_woo_cart' => array(
                        'default'   => false,
                        'type'      => 'checkbox',
                        'label'     => esc_html_x('Show Woo Cart', 'customizer', 'ogo')
                    ),
                    'custom_sidebar' => array(
                        'type'          => 'select',
                        'label'         => esc_html_x('Custom sidebar', 'customizer', 'ogo'),
                        'default'       => 'custom_sidebar',
                        'dependency'    => array(
                            'control'   => 'icon_custom_sb',
                            'operator'  => '==',
                            'value'     => 'true'
                        ),
                        'choices'       => array_merge( 
                            array(
                                'none'  => esc_html_x('None', 'customizer', 'ogo'),
                            ),
                            is_array(get_theme_mod('theme_sidebars')) ? get_theme_mod('theme_sidebars') : array()
                        ),
                    ),
                ),
                array(
                    'search_title' => array(
                        'type'      => 'text',
                        'label'     => esc_html_x('Search Title', 'customizer', 'ogo'),
                        'default'   => esc_html_x('WHAT ARE YOU LOOKING FOR?', 'customizer', 'ogo'),
                    ),
                    'top_bar_bg_color' => array(
                        'type'              => 'alpha-color',
                        'label'             => esc_html_x('Background', 'customizer', 'ogo'),
                        'default'           => '#262838',
                        'sanitize_callback' => 'wp_strip_all_tags',
                        'live_preview'      => array(
                            'trigger_class'     => '.top-bar-box',
                            'style_to_change'   => 'background-color',
                        )
                    ),
                    'top_bar_font_color' => array(
                        'type'              => 'alpha-color',
                        'label'             => esc_html_x('Fonts & Icons Color', 'customizer', 'ogo'),
                        'default'           => 'rgba(255,255,255,.7)',
                        'sanitize_callback' => 'wp_strip_all_tags',
                        'live_preview'      => array(
                            'trigger_class'     => '.top-bar-box .container > * > a, .header_icons > .mini-cart > a',
                            'style_to_change'   => 'color',
                        )
                    ),
                    'top_bar_font_color_hover' => array(
                        'type'              => 'alpha-color',
                        'label'             => esc_html_x('Fonts & Icons Hover', 'customizer', 'ogo'),
                        'default'           => '#fff',
                        'sanitize_callback' => 'wp_strip_all_tags'
                    ),
                    'top_bar_spacings' => array(
                        'type'          => 'multiple_input',
                        'label'         => esc_html_x('Spacings', 'customizer', 'ogo'),
                        'choices'       => array(
                            'top'  => array( 
                                'placeholder' => esc_html_x('Top (px or %)', 'customizer', 'ogo'), 
                                'value' => '10px'
                            ),
                            'bottom' => array( 
                                'placeholder' => esc_html_x('Bottom (px or %)', 'customizer', 'ogo'), 
                                'value' => '10px'
                            ),
                        )
                    ),
                )
            ),
        ),
        'logotype_section' => array(
            'title'     => esc_html_x('Logo', 'customizer', 'ogo'),
            'layout'    => array(
                'logotype' => array(
                    'type'          => 'wp_image',
                    'label'         => esc_html_x('Logo', 'customizer', 'ogo'),
                    'description'   => esc_html_x('To get a retina logo please upload a double-size image and set the image dimentions to fit the actual logo size', 'customizer', 'ogo'),
                ),
                'logo_dimensions' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Dimensions', 'customizer', 'ogo'),
                    'choices'       => array(
                        'width'  => array( 
                            'placeholder' => esc_html_x('Width (px or %)', 'customizer', 'ogo'), 
                            'value' => '142px' 
                        ),
                        'height' => array( 
                            'placeholder' => esc_html_x('Height (px or %)', 'customizer', 'ogo'), 
                            'value' => 0
                        ),
                    )
                ),
                'logo_margins' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Spacings', 'customizer', 'ogo'),
                    'choices'       => array(
                        'top'  => array( 
                            'placeholder' => esc_html_x('Top (px or %)', 'customizer', 'ogo'), 
                        ),
                        'right' => array( 
                            'placeholder' => esc_html_x('Right (px or %)', 'customizer', 'ogo'), 
                        ),
                        'bottom' => array( 
                            'placeholder' => esc_html_x('Bottom (px or %)', 'customizer', 'ogo'), 
                        ),
                        'left' => array( 
                            'placeholder' => esc_html_x('Left (px or %)', 'customizer', 'ogo'), 
                        ),
                    )
                ),
            )
        ),
        'menu_section' => array(
            'title'     => esc_html_x('Menu Appearance', 'customizer', 'ogo'),
            'layout'    => array_merge(
                array(
                    'menu_wide' => array(
                        'default'   => true,
                        'type'      => 'checkbox',
                        'label'     => esc_html_x('Apply full-width menu', 'customizer', 'ogo'),
                    )
                ),
                $ogo_typography_control,
                array(
                    'menu_font_color' => array(
                        'type'              => 'alpha-color',
                        'label'             => esc_html_x('Font Color', 'customizer', 'ogo'),
                        'default'           => PRIMARY_COLOR,
                        'sanitize_callback' => 'wp_strip_all_tags',
                    ),
                    'menu_accent_font_color' => array(
                        'type'              => 'alpha-color',
                        'label'             => esc_html_x('Accent Font Color', 'customizer', 'ogo'),
                        'default'           => SECONDARY_COLOR,
                        'sanitize_callback' => 'wp_strip_all_tags'
                    ),
                    'submenu_font_color' => array(
                        'type'              => 'alpha-color',
                        'label'             => esc_html_x('Submenu Font Color', 'customizer', 'ogo'),
                        'default'           => PRIMARY_COLOR,
                        'sanitize_callback' => 'wp_strip_all_tags',
                    ),
                    'submenu_font_color_hover' => array(
                        'type'              => 'alpha-color',
                        'label'             => esc_html_x('Submenu Accent Color', 'customizer', 'ogo'),
                        'default'           => SECONDARY_COLOR,
                        'sanitize_callback' => 'wp_strip_all_tags'
                    ),
                    'menu_spacings' => array(
                        'type'          => 'multiple_input',
                        'label'         => esc_html_x('Spacings', 'customizer', 'ogo'),
                        'choices'       => array(
                            'top'  => array( 
                                'placeholder' => esc_html_x('Top (px or %)', 'customizer', 'ogo'), 
                                'value' => '50px'
                            ),
                            'bottom' => array( 
                                'placeholder' => esc_html_x('Bottom (px or %)', 'customizer', 'ogo'), 
                                'value' => '48px'
                            ),
                        )
                    ),
                    'menu_mode' => array(
                        'default'       => 'desktop',
                        'type'          => 'radio',
                        'label'         => esc_html_x('Show desktop menu on:', 'customizer', 'ogo'),
                        'choices'       => array(
                            'desktop'       => esc_html_x('Desktops', 'customizer', 'ogo'),
                            'landscape'     => esc_html_x('Tablets Landscape', 'customizer', 'ogo'),
                            'both'          => esc_html_x('Landscape & Portrait Tablets', 'customizer', 'ogo'),
                        ),
                        'separator'     => 'line'
                    ),
                    'menu_add_search' => array(
                        'type'      => 'checkbox',
                        'label'     => esc_html_x('Show Search Button', 'customizer', 'ogo'),
                        'default'   => true,
                    ),
                    'menu_mini_cart' => array(
                        'type'      => 'checkbox',
                        'label'     => esc_html_x('Show Mini Cart', 'customizer', 'ogo'),
                        'default'   => true,
                    ),
                    'menu_button_title' => array(
                        'type'      => 'text',
                        'label'     => esc_html_x('Button Title', 'customizer', 'ogo'),
                        'default'   => '',
                    ),
                    'menu_button_url' => array(
                        'type'      => 'text',
                        'label'     => esc_html_x('Button URL', 'customizer', 'ogo'),
                        'default'   => "#",
                        'dependency'    => array(
                            'control'   => 'menu_button_title',
                            'operator'  => '!=',
                            'value'     => ''
                        ),
                    ),
                    'menu_button_blank' => array(
                        'type'      => 'checkbox',
                        'label'     => esc_html_x('Open in new window', 'customizer', 'ogo'),
                        'default'   => false,
                        'dependency'    => array(
                            'control'   => 'menu_button_title',
                            'operator'  => '!=',
                            'value'     => ''
                        ),
                    ),
                )
            )
        ),
        'title_area' => array(
            'title'     => esc_html_x('Title Area', 'customizer', 'ogo'),
            'layout'    => array(
                'title_area_spacings' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Title Spacing', 'customizer', 'ogo'),
                    'choices'       => array(
                        'top'  => array( 
                            'placeholder' => esc_html_x('Top (px)', 'customizer', 'ogo'), 
                            'value' => '72px' 
                        ),
                        'bottom' => array( 
                            'placeholder' => esc_html_x('Bottom (px)', 'customizer', 'ogo'), 
                            'value' => '65px' 
                        ),
                    )
                ),
                'mobile_title_area_spacings' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x(' Mobile Title Spacing', 'customizer', 'ogo'),
                    'choices'       => array(
                        'top'  => array( 
                            'placeholder' => esc_html_x('Top (px)', 'customizer', 'ogo'), 
                            'value' => '52px' 
                        ),
                        'bottom' => array( 
                            'placeholder' => esc_html_x('Bottom (px)', 'customizer', 'ogo'), 
                            'value' => '45px' 
                        ),
                    ),
                ),
                'title_archive_font_size' => array(
                    'type'          => 'textfield',
                    'label'         => esc_html_x('Title Font Size on Archive', 'customizer', 'ogo'),
                    'default'       => "90px",
                    'live_preview'      => array(
                        'trigger_class'     => 'body:not(.single) .page_title_container .page_title_customizer_size',
                        'style_to_change'   => 'font-size',
                    )
                ),
                'title_single_font_size' => array(
                    'type'          => 'textfield',
                    'label'         => esc_html_x('Title Font Size on Singles', 'customizer', 'ogo'),
                    'default'       => "60px",
                    'separator'     => 'line',
                    'live_preview'      => array(
                        'trigger_class'     => 'body.single .page_title_container .page_title_customizer_size',
                        'style_to_change'   => 'font-size',
                    )
                ),
                'title_custom_gradient' => array(
                    'default'   => false,
                    'type'      => 'checkbox',
                    'label'     => esc_html_x('Custom Gradient', 'customizer', 'ogo'),
                ),
                'title_background_gradient_1' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Bg Gradient 1', 'customizer', 'ogo'),
                    'default'           => '#00b2a3',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_custom_gradient',
                        'operator'  => '!=',
                        'value'     => 'true'
                    ),
                ),
                'title_background_gradient_2' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Bg Gradient 1', 'customizer', 'ogo'),
                    'default'           => '#0040a6',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_custom_gradient',
                        'operator'  => '!=',
                        'value'     => 'true'
                    ),
                ),
                'title_custom_gradient_css' => array(
                    'type'          => 'textarea',
                    'label'         => esc_html_x('Please, enter css code of custom gradient', 'customizer', 'ogo'),
                    'dependency'    => array(
                        'control'   => 'title_custom_gradient',
                        'operator'  => '==',
                        'value'     => 'true'
                    ),
                    'default'       => "",
                ),
                'title_area_mask' => array(
                    'default'   => false,
                    'type'      => 'checkbox',
                    'label'     => esc_html_x('Show Title Area Mask', 'customizer', 'ogo'),
                ),
                'title_share_bg' => array(
                    'default'   => false,
                    'type'      => 'checkbox',
                    'label'     => esc_html_x('Extend Background with Menu', 'customizer', 'ogo'),
                ),
                'title_area_bg' => array(
                    'type'          => 'wp_image',
                    'label'         => esc_html_x('Title Area Background', 'customizer', 'ogo'),
                ),
                'title_area_interactive' => array(
                    'type'          => 'wp_image',
                    'label'         => esc_html_x('Title Interactive Image', 'customizer', 'ogo'),
                ),
                'title_fields_hide' => array(
                    'type'          => 'select',
                    'label'         => esc_html_x('Hide', 'customizer', 'ogo'),
                    'default'       => 'none',
                    'choices'       => array(
                        'none'          => esc_html_x('None', 'customizer', 'ogo'),
                        'cats'          => esc_html_x( 'Categories', 'customizer', 'ogo' ),
                        'title'         => esc_html_x( 'Title', 'customizer', 'ogo' ),
                        'meta'          => esc_html_x( 'Meta', 'customizer', 'ogo' ),
                        'divider'       => esc_html_x( 'Divider', 'customizer', 'ogo' ),
                        'breadcrumbs'   => esc_html_x( 'Breadcrumbs', 'customizer', 'ogo' )
                    ),
                    'input_attrs'   => array(
                        'multiple'      => true
                    ),
                ),
                'title_categories_bg' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Categories Bg', 'customizer', 'ogo'),
                    'default'           => '#fff',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_fields_hide',
                        'operator'  => '!=',
                        'value'     => 'cats'
                    ),
                    'live_preview'      => array(
                        'trigger_class'     => '.page_title_container .single_post_categories',
                        'style_to_change'   => 'background-color',
                    )
                ),
                'title_categories_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Categories Color', 'customizer', 'ogo'),
                    'default'           => PRIMARY_COLOR,
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_fields_hide',
                        'operator'  => '!=',
                        'value'     => 'cats'
                    ),
                    'live_preview'      => array(
                        'trigger_class'     => '.page_title_container .single_post_categories a',
                        'style_to_change'   => 'color',
                    )
                ),
                'title_title_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Title Color', 'customizer', 'ogo'),
                    'default'           => '#fff',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_fields_hide',
                        'operator'  => '!=',
                        'value'     => 'title'
                    ),
                    'live_preview'      => array(
                        'trigger_class'     => '.page_title_container .page_title',
                        'style_to_change'   => 'color',
                    )
                ),
                'title_meta_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Meta Color', 'customizer', 'ogo'),
                    'default'           => '#fff',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_fields_hide',
                        'operator'  => '!=',
                        'value'     => 'meta'
                    ),
                    'live_preview'      => array(
                        'trigger_class'     => '.page_title_container .single_post_meta a',
                        'style_to_change'   => 'color',
                    )
                ),
                'title_divider_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Divider Color', 'customizer', 'ogo'),
                    'default'           => SECONDARY_COLOR,
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_fields_hide',
                        'operator'  => '!=',
                        'value'     => 'divider'
                    )
                ),
                'title_breadcrumbs_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Breadcrumbs Color', 'customizer', 'ogo'),
                    'default'           => 'rgba(255,255,255, .8)',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'    => array(
                        'control'   => 'title_fields_hide',
                        'operator'  => '!=',
                        'value'     => 'breadcrumbs'
                    ),
                    'live_preview'      => array(
                        'trigger_class'     => '.page_title_container .woocommerce-breadcrumb *, .page_title_container .bread-crumbs *',
                        'style_to_change'   => 'color',
                    )
                ),
                'title_mouse_animation' => array(
                    'default'   => true,
                    'type'      => 'checkbox',
                    'label'     => esc_html_x('Mouse Move Animation', 'customizer', 'ogo'),
                ),
                'title_scroll_animation' => array(
                    'default'   => true,
                    'type'      => 'checkbox',
                    'label'     => esc_html_x('Scroll Animation', 'customizer', 'ogo'),
                ),
            )
        ),
        'mobile_menu_section' => array(
            'title'     => esc_html_x('Mobile Menu', 'customizer', 'ogo'),
            'layout'    => array(
                'mobile_top_bar_logotype' => array(
                    'type'          => 'wp_image',
                    'label'         => esc_html_x('Top Bar Logotype', 'customizer', 'ogo'),
                    'description'   => esc_html_x('To get a retina logo please upload a double-size image and set the image dimentions to fit the actual logo size.', 'customizer', 'ogo'),
                ),
                'mobile_top_bar_logo_dimensions' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Top Bar Logo Dimensions', 'customizer', 'ogo'),
                    'choices'       => array(
                        'width'  => array( 
                            'placeholder' => esc_html_x('Width (px or %)', 'customizer', 'ogo'), 
                            'value' => '111px' 
                        ),
                        'height' => array( 
                            'placeholder' => esc_html_x('Height (px or %)', 'customizer', 'ogo'), 
                            'value' => '' 
                        ),
                    ),
                    'separator'     => 'line'
                ),
                'mobile_menu_logotype' => array(
                    'type'          => 'wp_image',
                    'label'         => esc_html_x('Menu Logotype', 'customizer', 'ogo'),
                    'description'   => esc_html_x('To get a retina logo please upload a double-size image and set the image dimentions to fit the actual logo size.', 'customizer', 'ogo'),
                ),
                'mobile_menu_logo_dimensions' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Menu Logo Dimensions', 'customizer', 'ogo'),
                    'choices'       => array(
                        'width'  => array( 
                            'placeholder' => esc_html_x('Width (px or %)', 'customizer', 'ogo'), 
                            'value' => '142px' 
                        ),
                        'height' => array( 
                            'placeholder' => esc_html_x('Height (px or %)', 'customizer', 'ogo'), 
                            'value' => '' 
                        ),
                    ),
                    'separator'     => 'line'
                ),
                'mobile_show_minicart' => array(
                    'default'   => false,
                    'type'      => 'checkbox',
                    'label'     => esc_html_x('Show Mini-Cart', 'customizer', 'ogo'),
                ),
                'mobile_menu_spacings' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Spacings', 'customizer', 'ogo'),
                    'choices'       => array(
                        'top'  => array( 
                            'placeholder' => esc_html_x('Top (px or %)', 'customizer', 'ogo'), 
                            'value' => '13px'
                        ),
                        'bottom' => array( 
                            'placeholder' => esc_html_x('Bottom (px or %)', 'customizer', 'ogo'), 
                            'value' => '13px'
                        ),
                    )
                ),
                'mobile_topbar_bg' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Top Bar Background', 'customizer', 'ogo'),
                    'default'           => "#fff",
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'live_preview'      => array(
                        'trigger_class'     => '.site-header-mobile .top-bar-box',
                        'style_to_change'   => 'background-color',
                    )
                ),
                'mobile_icons_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Icons Color', 'customizer', 'ogo'),
                    'default'           => PRIMARY_COLOR,
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'live_preview'      => array(
                        'trigger_class'     => '.site-header-mobile .menu-trigger span',
                        'style_to_change'   => 'background-color',
                    )
                ),
                'mobile_menu_font_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Menu Font Color', 'customizer', 'ogo'),
                    'default'           => PRIMARY_COLOR,
                    'sanitize_callback' => 'wp_strip_all_tags',
                ),
                'mobile_accent_font_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Menu Accent Color', 'customizer', 'ogo'),
                    'default'           => THIRD_COLOR,
                    'sanitize_callback' => 'wp_strip_all_tags',
                ),
            )
        ),
        'sticky_menu_section' => array(
            'title'     => esc_html_x('Sticky Menu', 'customizer', 'ogo'),
            'layout'    => array(
                'sticky_logotype' => array(
                    'type'          => 'wp_image',
                    'label'         => esc_html_x('Sticky Logo', 'customizer', 'ogo'),
                    'description'   => esc_html_x('To get a retina logo please upload a double-size image and set the image dimentions to fit the actual logo size.', 'customizer', 'ogo'),
                ),
                'sticky_logo_dimensions' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Sticky Logo Dimensions', 'customizer', 'ogo'),
                    'choices'       => array(
                        'width'  => array( 
                            'placeholder' => esc_html_x('Width (px or %)', 'customizer', 'ogo'), 
                            'value' => '142px' 
                        ),
                        'height' => array( 
                            'placeholder' => esc_html_x('Height (px or %)', 'customizer', 'ogo'), 
                            'value' => '' 
                        ),
                    )
                ),
                'sticky_spacings' => array(
                    'type'          => 'multiple_input',
                    'label'         => esc_html_x('Sticky Menu Spacings', 'customizer', 'ogo'),
                    'choices'       => array(
                        'top'  => array( 
                            'placeholder' => esc_html_x('Top (px or %)', 'customizer', 'ogo'), 
                            'value' => '0'
                        ),
                        'bottom' => array( 
                            'placeholder' => esc_html_x('Bottom (px or %)', 'customizer', 'ogo'), 
                            'value' => '0'
                        ),
                    )
                ),
                'sticky_shadow' => array(
                    'default'   => false,
                    'type'      => 'checkbox',
                    'label'     => esc_html_x('Add Shadow', 'customizer', 'ogo'),
                ),
                'sticky_shadow_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Shadow Color', 'customizer', 'ogo'),
                    'default'           => 'rgba(16,1,148, 0.05)',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'dependency'           => array(
                        'control'   => 'sticky_shadow',
                        'operator'  => '==',
                        'value'     => 'true'
                    ),
                ),
                'sticky_background' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Background Color', 'customizer', 'ogo'),
                    'default'           => '#fff',
                    'sanitize_callback' => 'wp_strip_all_tags',
                    'live_preview'      => array(
                        'trigger_class'     => '.site-sticky',
                        'style_to_change'   => 'background-color',
                    )
                ),
                'sticky_font_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Font Color', 'customizer', 'ogo'),
                    'default'           => PRIMARY_COLOR,
                    'sanitize_callback' => 'wp_strip_all_tags',
                ),
                'sticky_accent_font_color' => array(
                    'type'              => 'alpha-color',
                    'label'             => esc_html_x('Font Accent Color', 'customizer', 'ogo'),
                    'default'           => THIRD_COLOR,
                    'sanitize_callback' => 'wp_strip_all_tags'
                ),
                'custom_sticky' => array(
                    'type'          => 'select',
                    'label'         => esc_html_x('Sticky Menu Template', 'customizer', 'ogo'),
                    'default'       => 'default',
                    'choices'       => array(
                        'default'   => esc_html_x('Default', 'customizer', 'ogo'),
                    ) + $custom_sticky_headers,
                    'separator'     => 'line-top',
                    'description'   => esc_html_x('All settings above are applied for default sticky template only', 'customizer', 'ogo'),
                )
            )
        ),
        'header_section' => array(
            'title'     => esc_html_x('Custom Header', 'customizer', 'ogo'),
            'layout'    => array(
                'custom_header' => array(
                    'type'          => 'select',
                    'label'         => esc_html_x('Custom Header Template', 'customizer', 'ogo'),
                    'default'       => 'default',
                    'choices'       => array(
                        'default'   => esc_html_x('Default', 'customizer', 'ogo'),
                    ) + $custom_headers,
                    'description'   => esc_html_x('The following tab settings will be ingnored if custom headers are applied: Top Bar, Logotype, Menu', 'customizer', 'ogo'),
                ),
            )
        )
	)
?>